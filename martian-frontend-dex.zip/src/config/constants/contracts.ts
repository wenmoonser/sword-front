export default {
  cake: {
    56: '0x65d8861D66F0B77fAf82E0CC8377eF4539b6C69a',
    97: '',
  },
  masterChef: {
    56: '0x48F1817cccF91bEEe279a5df7D16bCC91C10a490',
    97: '',
  },
  wbnb: {
    56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    97: '',
  },
  lottery: {
    56: '',
    97: '',
  },
  lotteryNFT: {
    56: '',
    97: '',
  },
  mulltiCall: {
    56: '0x1ee38d535d541c55c9dae27b12edf090c608e6fb',
    97: '0x67ADCB4dF3931b0C5Da724058ADC2174a9844412',
  },
  busd: {
    56: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
    97: '',
  },
  referral: {
    56: '0xdc150bcdb6ad84ac7915e6c99a84f4f2eee85dc3',
    97: '',
  },
}
