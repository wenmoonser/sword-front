import { ReferralConfig } from './types'

const referrals: ReferralConfig = {
  totalReferrals: 0,
  totalReferralCommissions: 0,
}

export default referrals
